# A demo of using PyCryptodome for AES encryption
# for more information, please refer to https://pycryptodome.readthedocs.io/en/latest/src/cipher/aes.html
from Crypto.Cipher import AES
# import padding package
from Crypto.Util.Padding import pad, unpad

# define the symmetric key
my_key = "The_key_for_demo"   # can be 16, 24, 32 bytes

# Example with ECB mode (DO NOT USE ECB MODE IN PRACTICE!!!)
# initiate the AES with the key and mode-of-operation (CBC as an example)
enc_cipher = AES.new(str.encode(my_key), AES.MODE_ECB)

# Plaintext must be k * 16 bytes if not using padding
ptx = "Hello World!!!!!"

# encrypt (without padding)
ctx = enc_cipher.encrypt(str.encode(ptx))

# encrypt (with padding): ctx = enc_cipher.encrypt(pad(ptx, AES.block_size))
print("Ciphertext: {}".format(ctx))


# decrypt
dec_cipher = AES.new(str.encode(my_key), AES.MODE_ECB)

# decrypt
ptx = dec_cipher.decrypt(ctx)
# decrypt and unpad the decrypted text: ptx = unpad(dec_cipher.decrypt(ctx), AES.block_size)
